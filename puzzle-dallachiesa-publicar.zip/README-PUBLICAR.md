# Publicar Puzzle Dallachiesa

Esta carpeta contiene un juego web estatico. Se puede publicar en Netlify, Vercel, GitHub Pages o cualquier hosting que acepte archivos HTML/CSS/JS.

## Opcion rapida: Netlify Drop

1. Entrar a https://app.netlify.com/drop
2. Arrastrar esta carpeta completa: `puzzle-dallachiesa`
3. Esperar unos segundos.
4. Copiar el link publico que genera Netlify.

## Archivos necesarios

- `index.html`
- `styles.css`
- `app.js`
- `logo-dallachiesa.jpeg`

No requiere servidor ni base de datos.
